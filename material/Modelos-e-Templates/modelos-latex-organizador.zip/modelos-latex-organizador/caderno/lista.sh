% generate list of tex files with import commands
#!\bin\bash
# echo "% for use in combine (using amsart hack)."
echo "% tex file list for combine.cls."
for f in $(ls *.tex); do
  # echo "\gdef\authors{}\gdef\addresses{} %cleanning"
  echo "\\import{${f%\.tex}}"; 
done
#  echo "\gdef\authors{}\gdef\addresses{} %cleanning"
