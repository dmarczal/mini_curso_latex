
Brief summary:

        "Breve  Introducao ao  LaTeX2e" (A brief introduction
  to LaTeX2e)  is  a  Portuguese tutorial about LaTeX2e in PS
  format.  It has  about 80  pages organized  in  5  chapters
  and 4 appendixes. The chapters are:  Basic concepts; Mathe-
  matical formulae; Tables; Including graphics in EPS format;
  Diagrams  with  Xy-pic.  The  appendixes  are: Mathematical
  symbols; Letters; FoilTeX; LaTeX resources in the Internet.

------------------------------------------------------------
(C) April/2000, by Lenimar N. Andrade -- lenimar@mat.ufpb.br

